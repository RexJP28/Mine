const { SimpleScorecardGenerator } = require('./scorecardGenerator');

async function testSimpleScorecards() {
    // Test data for different match scenarios
    const testMatches = {
        psl: {
            team1: 'Karachi Kings',
            team2: 'Peshawar Zalmi',
            score: {
                runs: 185,
                wickets: 4,
                overs: 15,
                balls: 2
            },
            currentInnings: 1
        },
        bpl: {
            team1: 'Rangpur Riders',
            team2: 'Dhaka Dominators',
            score: {
                runs: 165,
                wickets: 6,
                overs: 16,
                balls: 4
            },
            currentInnings: 1
        },
        international_t20: {
            team1: 'India',
            team2: 'Australia',
            score: {
                runs: 190,
                wickets: 3,
                overs: 18,
                balls: 0
            },
            currentInnings: 1
        },
        bbl: {
            team1: 'Perth Scorchers',
            team2: 'Melbourne Stars',
            score: {
                runs: 175,
                wickets: 5,
                overs: 17,
                balls: 3
            },
            currentInnings: 1
        }
    };

    // Test PSL style
    console.log('\nGenerating PSL style scorecard...');
    const pslGenerator = new SimpleScorecardGenerator('PSL');
    const pslPath = pslGenerator.generateScorecard(testMatches.psl);
    console.log('PSL scorecard generated:', pslPath);

    // Test BPL style
    console.log('\nGenerating BPL style scorecard...');
    const bplGenerator = new SimpleScorecardGenerator('BPL');
    const bplPath = bplGenerator.generateScorecard(testMatches.bpl);
    console.log('BPL scorecard generated:', bplPath);

    // Test International T20 style
    console.log('\nGenerating International T20 style scorecard...');
    const t20Generator = new SimpleScorecardGenerator('INTERNATIONAL', 't20');
    const t20Path = t20Generator.generateScorecard(testMatches.international_t20);
    console.log('International T20 scorecard generated:', t20Path);

    // Test BBL style
    console.log('\nGenerating BBL style scorecard...');
    const bblGenerator = new SimpleScorecardGenerator('BBL');
    const bblPath = bblGenerator.generateScorecard(testMatches.bbl);
    console.log('BBL scorecard generated:', bblPath);
}

testSimpleScorecards().catch(console.error);