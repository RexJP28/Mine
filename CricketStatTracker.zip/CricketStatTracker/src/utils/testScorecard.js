const { createPSLScorecard, createIPLScorecard } = require('./messages');

function createTestMatch(league) {
    return {
        score: {
            innings1: {
                runs: 185,
                wickets: 4,
                overs: 15,
                balls: 2,
                powerPlayScore: '52/1',
                lastFiveOvers: '12,14,8,15,11'
            }
        },
        currentInnings: 1,
        battingStats: {
            'Babar Azam': { runs: 82, balls: 48, fours: 8, sixes: 3, phase: 'Middle' },
            'Mohammad Rizwan': { runs: 45, balls: 28, fours: 4, sixes: 2, phase: 'PowerPlay' },
            'Iftikhar Ahmed': { runs: 35, balls: 15, fours: 2, sixes: 4, phase: 'Death' }
        },
        bowlingStats: {
            'Shaheen Afridi': { overs: 4, maidens: 1, runs: 28, wickets: 2, dots: 14 },
            'Haris Rauf': { overs: 3, maidens: 0, runs: 35, wickets: 1, dots: 8 },
            'Mohammad Wasim': { overs: 2, maidens: 0, runs: 22, wickets: 1, dots: 5 }
        },
        impactPlayerAvailable: true,
        timeoutAvailable: true,
        drsAvailable: true
    };
}

// Create test matches
const pslMatch = createTestMatch('psl');
const iplMatch = createTestMatch('ipl');

// Generate all scorecard types
console.log('\n=== PSL SCORECARDS ===');
console.log('\nPSL Match Summary:');
console.log(createPSLScorecard(pslMatch, 'summary'));
console.log('\nPSL Batting Card:');
console.log(createPSLScorecard(pslMatch, 'batting'));
console.log('\nPSL Bowling Card:');
console.log(createPSLScorecard(pslMatch, 'bowling'));

console.log('\n=== IPL SCORECARDS ===');
console.log('\nIPL Match Summary:');
console.log(createIPLScorecard(iplMatch, 'summary'));
console.log('\nIPL Batting Card:');
console.log(createIPLScorecard(iplMatch, 'batting'));
console.log('\nIPL Bowling Card:');
console.log(createIPLScorecard(iplMatch, 'bowling'));

module.exports = {
    createTestMatch
};