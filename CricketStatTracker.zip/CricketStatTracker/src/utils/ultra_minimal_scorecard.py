def create_scorecard(team1, team2, score, overs, result):
    scorecard = f"""
=================================
{team1} vs {team2}
---------------------------------
Score: {score} ({overs})
Result: {result}
=================================
"""
    print(scorecard)

if __name__ == '__main__':
    # Test match data
    create_scorecard(
        team1="Pakistan",
        team2="India",
        score="185/4",
        overs="15.2",
        result="Pakistan won by 6 wickets"
    )
