const { ScorecardGenerator } = require('./scorecardGenerator');
const fs = require('fs');
const path = require('path');

async function testScorecards() {
    const testMatch = {
        score: {
            innings1: {
                runs: 185,
                wickets: 4,
                overs: 15,
                balls: 2
            }
        },
        battingStats: {
            'Babar Azam': { runs: 82, balls: 48, fours: 8, sixes: 3 },
            'Mohammad Rizwan': { runs: 45, balls: 28, fours: 4, sixes: 2 },
            'Iftikhar Ahmed': { runs: 35, balls: 15, fours: 2, sixes: 4 }
        },
        bowlingStats: {
            'Shaheen Afridi': { overs: 4, maidens: 1, runs: 28, wickets: 2 },
            'Haris Rauf': { overs: 3, maidens: 0, runs: 35, wickets: 1 },
            'Mohammad Wasim': { overs: 2, maidens: 0, runs: 22, wickets: 1 }
        }
    };

    // Ensure output directory exists
    const outputDir = path.join(__dirname, '../../output');
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    // Generate PSL style scorecards
    const pslGenerator = new ScorecardGenerator('PSL');
    const pslSummary = await pslGenerator.generateMatchSummary(testMatch);
    const pslBatting = await pslGenerator.generateBattingCard(testMatch);
    const pslBowling = await pslGenerator.generateBowlingCard(testMatch);

    fs.writeFileSync(path.join(outputDir, 'psl_summary.png'), pslSummary);
    fs.writeFileSync(path.join(outputDir, 'psl_batting.png'), pslBatting);
    fs.writeFileSync(path.join(outputDir, 'psl_bowling.png'), pslBowling);

    // Generate IPL style scorecards
    const iplGenerator = new ScorecardGenerator('IPL');
    const iplSummary = await iplGenerator.generateMatchSummary(testMatch);
    const iplBatting = await iplGenerator.generateBattingCard(testMatch);
    const iplBowling = await iplGenerator.generateBowlingCard(testMatch);

    fs.writeFileSync(path.join(outputDir, 'ipl_summary.png'), iplSummary);
    fs.writeFileSync(path.join(outputDir, 'ipl_batting.png'), iplBatting);
    fs.writeFileSync(path.join(outputDir, 'ipl_bowling.png'), iplBowling);

    console.log('Generated all scorecard images in the output directory');
}

async function testBroadcastScorecards() {
    const testMatch = {
        score: {
            innings1: {
                runs: 185,
                wickets: 4,
                overs: 15,
                balls: 2,
                lastFiveOvers: '12,14,8,15,11'
            }
        },
        battingStats: {
            'Babar Azam': { runs: 82, balls: 48, fours: 8, sixes: 3, phase: 'Middle' },
            'Mohammad Rizwan': { runs: 45, balls: 28, fours: 4, sixes: 2, phase: 'PowerPlay' },
            'Iftikhar Ahmed': { runs: 35, balls: 15, fours: 2, sixes: 4, phase: 'Death' }
        },
        bowlingStats: {
            'Shaheen Afridi': { overs: 4, maidens: 1, runs: 28, wickets: 2, dots: 14 },
            'Haris Rauf': { overs: 3, maidens: 0, runs: 35, wickets: 1, dots: 8 },
            'Mohammad Wasim': { overs: 2, maidens: 0, runs: 22, wickets: 1, dots: 5 }
        }
    };

    // Ensure output directory exists
    const outputDir = path.join(__dirname, '../../output');
    if (!fs.existsSync(outputDir)) {
        fs.mkdirSync(outputDir, { recursive: true });
    }

    // Generate PSL style scorecard
    const pslGenerator = new ScorecardGenerator('PSL');
    const pslScorecard = pslGenerator.generateBroadcastStyle(testMatch);
    console.log('Generated PSL scorecard:', pslScorecard);

    // Generate IPL style scorecard
    const iplGenerator = new ScorecardGenerator('IPL');
    const iplScorecard = iplGenerator.generateBroadcastStyle(testMatch);
    console.log('Generated IPL scorecard:', iplScorecard);

    // Generate International style scorecard
    const intlGenerator = new ScorecardGenerator('INTERNATIONAL');
    const intlScorecard = intlGenerator.generateBroadcastStyle(testMatch);
    console.log('Generated International scorecard:', intlScorecard);

    console.log('Generated all broadcast-style scorecard images in the output directory');
}

testScorecards().catch(console.error);
testBroadcastScorecards().catch(console.error);